
function spawn_player()

    for i, cellData in ipairs(grid_table) do
        if cellData.id == 1 then 
            cellData.occupied = true
            print("SPAWNED ON:", cellData.id, cellData.occupied)
        end 

    end 
end 