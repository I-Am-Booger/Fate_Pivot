function load_how_to_play_text()

    if current_language == "es" then
        how_to_play_text_1 = love.filesystem.read("states/how_to_play_text/spanish_1.txt")
        how_to_play_text_2 = love.filesystem.read("states/how_to_play_text/spanish_2.txt")
        how_to_play_text_3 = love.filesystem.read("states/how_to_play_text/spanish_3.txt")
    else
        how_to_play_text_1 = love.filesystem.read("states/how_to_play_text/english_1.txt")
        how_to_play_text_2 = love.filesystem.read("states/how_to_play_text/english_2.txt")
        how_to_play_text_3 = love.filesystem.read("states/how_to_play_text/english_3.txt")
    end
end