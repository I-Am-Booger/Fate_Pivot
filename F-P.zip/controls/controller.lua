-- controller



function love.gamepadpressed(joystick, input)
    input_device = "controller"

    -- Let the shared menu handler process D-pad input
    handle_title_selection(input)
    handle_option_selection(input)

    -- Starting and changing states
    if input == "start" and game_state == "splash_screen" then 
        game_state = "title" return 

        elseif input == "start" and game_state == "title" then 
            game_state = "mode_select" return

        elseif (input == "start" or input == "a") and game_state == "mode_select" and title_selection == 1 then 
            reset_game() 
            game_state = "play" 
            spawn_player() 
            save_data.statistics.career.games_played = save_data.statistics.career.games_played + 1
            save_game_data() return

        elseif (input == "start" or input == "a") and game_state == "mode_select" and title_selection == 2 then
            game_state = "statistics" return 
        
        elseif (input == "start" or input == "a") and game_state == "mode_select" and title_selection == 3 then 
            game_state = "options" return

        elseif (input == "start" or input == "a") and game_state == "mode_select" and title_selection == 4 then     
            game_state = "how_to_play" return 
       

            -- I put game_state = "exit" so that a quick glace I could see whare I was in the code        
        elseif (input == "start" or input == "a") and game_state == "mode_select" and title_selection == 5 then 
            game_state = "exit" love.event.quit() 
        

    -- how to play 
        elseif (input == "back" or input == "b") and game_state == "how_to_play" then 
            game_state = "mode_select" return

        elseif(input == "dpleft") and game_state == "how_to_play" then
            page_number = page_number - 1 
            if page_number < 1 then page_number = 3 return end 

        elseif(input == "dpright") and game_state == "how_to_play" then
            page_number = page_number + 1 
            if page_number > 3 then page_number = 1 return end  


        elseif (input == "back" or input == "b") and game_state == "options"  then 
            game_state = "mode_select" return

            
        elseif (input == "dpleft" or input =="dpright") and game_state == "options" and options_selection == 1 then
            toggle_fullscreen() return
    
   
        elseif (input == "dpleft") and game_state == "options" and options_selection == 2 then
            change_resolution(-1)
            return

        elseif (input == "dpright") and game_state == "options" and options_selection == 2 then
            change_resolution(1) 
            return  
              
        elseif(input == "dpleft") and game_state == "options" and options_selection == 3 then 
            change_music_volume(-1) return 

        elseif(input == "dpright") and game_state == "options" and options_selection == 3 then 
            change_music_volume(1) return

        elseif(input == "dpleft") and game_state == "options" and options_selection == 4 then 
            change_sound_volume(-1) return

        elseif(input == "dpright") and game_state == "options" and options_selection == 4 then 
            change_sound_volume(1) return 

        elseif (input == "dpleft" or input == "dpright") and game_state == "options" and options_selection == 5 then
            change_language() return


        elseif (input == "back" or input == "b") and game_state == "statistics" then
            game_state = "mode_select" return

        elseif input == "start" and game_state == "play" then game_state = "pause" return

        elseif input == "start" and game_state == "pause" then game_state = "play" return

        elseif (input == "back") and (game_state == "play" or game_state == "pause")
            then game_state = "mode_select" return
            
        elseif input == "start" and game_state == "game_over" then
            game_state = "mode_select" return
             
    end

    -- Gameplay controls
    if game_state == "play" then
        
        if devil_fate_active == true then
            if input == "dpup" then move_selector("down") end
            if input == "dpdown" then move_selector("up") end
            if input == "dpleft" then move_selector("right") end
            if input == "dpright" then move_selector("left") end
        
            else
                if input == "dpup" then move_selector("up") end
                if input == "dpdown" then move_selector("down") end
                if input == "dpleft" then move_selector("left") end
                if input == "dpright" then move_selector("right") end
        end     
        
        if input == "y" then handle_destroy_button("Y", joystick) end
        if input == "x" then handle_destroy_button("X", joystick) end
        if input == "a" then handle_destroy_button("A", joystick) end
        if input == "b" then handle_destroy_button("B", joystick) end

        if input == "rightshoulder" then 
            destroy_player() 
            play_respawn_click() end
        
        if input == "leftshoulder" then
            spawn_l1_blocks() end  
    end
end

function love.joystickadded(joystick)
    print("Controller added: " .. joystick:getName())
    load_buttons()
end

function love.joystickremoved(joystick)
    print("Controller removed: " .. joystick:getName())
    load_buttons()
end
