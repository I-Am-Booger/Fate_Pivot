function count_bad_blocks()
    local count = 0

    for i, cell in ipairs(grid_table) do
        if cell.owner == "bad" then 
            count = count + 1
        end
    end

    return count 
end 

function update_occupancy_timer()
    local bad_count = count_bad_blocks()

    local level_timer = base_player_timer - ((level - 1) * 0.10)

    local occupancy_penalty - bad_count * 0.05
    player_timer_max = level_timer - occupancy_penalty

    player_timer_max = math.max(0.5, player_timer_max)


    love.graphics.print("Bad Blocks: " .. count_bad_blocks(), 1600, 360)

love.graphics.print("Max Timer: " .. string.format("%.2f", player_timer_max), 1600, 420)
end 