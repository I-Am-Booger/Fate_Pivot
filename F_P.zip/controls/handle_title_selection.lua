function handle_title_selection(input)
   if game_state == "mode_select" then   

        -- Down
        if input == "dpdown" or input == "s" or input == "down" then
            title_selection = title_selection + 1
            
            if title_selection > 5 then title_selection = 1 end
        end

        -- Up
        if input == "dpup" or input == "w" or input == "up" then
            title_selection = title_selection - 1
            
            if title_selection < 1 then title_selection = 5 end
        end
    end
end 