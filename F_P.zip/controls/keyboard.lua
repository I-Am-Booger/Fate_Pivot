-- keyboard
function love.keypressed(key)
    if key == "w" then move_selector("up") end
    if key == "s" then move_selector("down") end 
    if key == "a" then move_selector("left") end 
    if key == "d" then move_selector("right") end 

    if key == "return" then end -- then pauses game

    if key == "i" then destroy_bad_block("T") end    
    if key == "k" then destroy_bad_block("x") end    
    if key == "j" then destroy_bad_block("S") end    
    if key == "l" then destroy_bad_block("O") end    
    
    if key == "r" then destroy_player() end    

end 