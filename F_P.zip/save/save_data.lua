save_data = {
    settings = {
        music_volume = 1,
        sound_volume = 1,
        fullscreen = false,
        resolution_index = 1,
        language = "en"
    },

    statistics = {
        career = {
            games_played = 0,
            highest_score = 0,
            highest_level = 1,
            total_time_played = 0
        },

        gameplay = {
            highest_multiplier = 1,
            bad_blocks_destroyed = 0,
            wrong_buttons_pressed = 0,
            fate_blocks_triggered = 0,
            longest_survival = 0
        }
    }
}