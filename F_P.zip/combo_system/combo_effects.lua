function activate_combo(color)
    if color == "red" then
        for _, cell in ipairs(grid_table) do
            if cell.row == current_player_cell.row
            and cell.owner == "bad" then

                save_data.statistics.gameplay.bad_blocks_destroyed =
                    save_data.statistics.gameplay.bad_blocks_destroyed + 1

                start_block_destruction_effect(cell)

                cell.occupied = false
                cell.owner = nil
                cell.color = nil
                cell.button = nil

                add_score(10)
            end
        end

    elseif color == "blue" then
        for _, cell in ipairs(grid_table) do
            if cell.x == current_player_cell.x
            and cell.owner == "bad" then

                save_data.statistics.gameplay.bad_blocks_destroyed =
                    save_data.statistics.gameplay.bad_blocks_destroyed + 1

                start_block_destruction_effect(cell)

                cell.occupied = false
                cell.owner = nil
                cell.color = nil
                cell.button = nil

                add_score(10)
            end
        end

    elseif color == "green" then
        player_timer = math.min(player_timer + 3, player_timer_max)

        bad_timer = math.min(bad_timer + 2, bad_timer_max)

        if l1_bonus_timer > 0 then 
            local green_timer_bonus = math.min(level * 0.20, 2.00)
            
            l1_bonus_timer = l1_bonus_timer + 2.00 

            bad_timer = math.min(bad_timer + green_timer_bonus, bad_timer_max)
            player_timer = math.min(player_timer + green_timer_bonus, player_timer_max)
        end 


    elseif color == "yellow" then
        local yellow_bad = {}

        for _, cell in ipairs(grid_table) do
            if cell.occupied == true
            and cell.owner == "bad" then
                table.insert(yellow_bad, cell)
            end
        end

        for i = 1, 6 do
            if #yellow_bad == 0 then
                break
            end

            local random_index =
                love.math.random(1, #yellow_bad)

            local cell = yellow_bad[random_index]

            save_data.statistics.gameplay.bad_blocks_destroyed =
                save_data.statistics.gameplay.bad_blocks_destroyed + 1

            start_block_destruction_effect(cell)

            cell.occupied = false
            cell.owner = nil
            cell.color = nil
            cell.button = nil

            add_score(10)

            table.remove(yellow_bad, random_index)
        end
    end

    save_game_data()
end