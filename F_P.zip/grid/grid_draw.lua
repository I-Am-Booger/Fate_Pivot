--[[  
    1. Draws the visible game board.
    2. cells() draws one row of grid cells.
    3. grid() draws the full 32-cell board.
    4. draw_selector() draws the current selection outline.
]]

function cells(num, x, y)
    local c = cell
    
    for i = 1, num do             
        love.graphics.rectangle("line", x, y, c, c)
        x = x + c
    end  
end 

function grid() -- 
    local x = borderX
    local y = borderY
    local c = cell
    love.graphics.setColor(1,1,1)
    love.graphics.setLineWidth(4) 
        cells(4, x, y)
        x = x - c
        y = y + c
        cells(6, x, y) 
        y = y + c
        cells(6, x, y)
        y = y + c
        cells(6, x, y)
        y = y + c
        cells(6, x, y) 
        x = x + c
        y = y + c
        cells(4, x, y) 
end 

function draw_selector()
    if selectedCell == nil then 
        return 
    end 

    love.graphics.setColor(1,0,1)
    love.graphics.setLineWidth(8)

    love.graphics.rectangle("line", selectedCell.x, selectedCell.y, selectedCell.w, selectedCell.h)
end 

