--[[ 
        1. This is the file to buid the grid to hold the cell info
        2. x, y, amd c are short hand for dimensions. id = 1 as a shorthand for incrmention        
        3. grid_table hold a dictionary type list with the info for each cell in the grid 
        4. grid blocks makes a line of blocks()
        5.  building_the_grid() takes gridblocks draws a line of blocks and then changes the 
            cordanance for the next time grid blocks is called  
]]

local x = borderX 
local y = borderY
local c = cell
local id = 1

grid_table = {}

function grid_blocks(num, x, y)
    
    for i = 1, num do
        local gt = {id = id, x = x , y = y, w = c, h = c, 
        occupied = false, owner = nil, color = nil, button = nil }     
        
        table.insert(grid_table, gt)
        id = id + 1
        x = x + c
    end  
end 

function building_the_grid()  

    grid_blocks(4, x, y)
    x = x - c
    y = y + c
    grid_blocks(6, x, y)
    y = y + c
    grid_blocks(6, x, y)
    y = y + c
    grid_blocks(6, x, y)
    y = y + c
    grid_blocks(6, x, y)
    x = x + c
    y = y + c
    grid_blocks(4, x ,y)
end 

function draw_block() -- we are felling in the blocks to create the player inside of them
    for i, cellData in ipairs(grid_table) do 
        if cellData.occupied == true then -- once it is true it draws a block
    
        if cellData.color == "blue" then
            love.graphics.setColor(0,0,1)
        elseif cellData.color == "green" then
            love.graphics.setColor(0,1,0)
        elseif cellData.color == "red" then
            love.graphics.setColor(1,0,0)
        elseif cellData.color == "yellow" then
            love.graphics.setColor(1,1,0)
        elseif cellData.color =="white" then
            love.graphics.setColor(1,1,1)
        end
  
        love.graphics.rectangle("fill", cellData.x, cellData.y, cellData.w, cellData.h)
     
        end 
    end
end 


